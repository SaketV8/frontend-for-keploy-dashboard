// import { useEffect } from "react";
// import useAuth from "@/hooks/useAuth";
// import { apiClientWithAuth } from "@/lib/axios";
// import { authStore } from "@/auth/stores/authStore";
// // import { authStore } from "@/auth/stores/authStore";

// const useAxiosWithAuth = () => {
//   const LOG_TITLE =
//     "================\n🎀 useAxiosWithAuth Hooks\n================\n";

//   //////////////////////////////////////////////////
//   const createLogger = () => {
//     let count = 0;
//     return (msg) => {
//       count++;
//       console.log(LOG_TITLE, `${msg}\n----\ncount: ${count}`);
//     };
//   };
//   const log = createLogger();
//   //////////////////////////////////////////////////
//   const { setAuth } = useAuth();
//   const auth = authStore.get();
//   // const { auth, setAuth } = useAuth();

//   useEffect(() => {
//     // Request Interceptor: Attach Access Token
//     // const auth = authStore.get();
//     const requestInterceptor = apiClientWithAuth.interceptors.request.use(
//       (config) => {
//         if (auth?.token) {
//           // console.log(LOG_TITLE, `🔥 Bearer ${auth.token}`);
//           log(`🔥 Bearer ${auth.token}`)
//           config.headers.Authorization = `Bearer ${auth.token}`;
//         }
//         return config;
//       },
//       (error) => Promise.reject(error)
//     );

//     // Response Interceptor: Handle Token Expiry
//     const responseInterceptor = apiClientWithAuth.interceptors.response.use(
//       (response) => response,
//       async (error) => {
//         if (error.response?.status === 401) {
//           try {
//             const refreshResponse = await apiClientWithAuth.get(
//               "/auth/refreshtoken"
//             );
//             const newAccessToken = refreshResponse.data.accessToken;

//             // setAuth((prev) => ({ ...prev, token: newAccessToken }));
//             setAuth({ ...authStore.get(), token: newAccessToken });

//             // Retry original request with new token
//             error.config.headers.Authorization = `Bearer ${newAccessToken}`;
//             return apiClientWithAuth(error.config);
//           } catch (refreshError) {
//             console.error(LOG_TITLE, "Failed to refresh token", refreshError);
//             // Logout user
//             setAuth({});
//             // setAuth(null);
//             return Promise.reject(refreshError);
//           }
//         }
//         return Promise.reject(error);
//       }
//     );

//     // Cleanup: Remove interceptors when component unmounts
//     return () => {
//       apiClientWithAuth.interceptors.request.eject(requestInterceptor);
//       apiClientWithAuth.interceptors.response.eject(responseInterceptor);
//     };
//   }, [auth]);
//   // }, [auth]);
//   // }, [auth, setAuth]);

//   return apiClientWithAuth;
// };

// export default useAxiosWithAuth;

// import { useEffect, useRef } from "react";
// import { authStore } from "@/auth/stores/authStore";
// import { apiClientWithAuth } from "@/lib/axios";
// import useAuth from "@/hooks/useAuth";

// const useAxiosWithAuth = () => {
//   const LOG_TITLE = "🎀 useAxiosWithAuth\n\n";
//   const { setAuth } = useAuth(); // ✅ Reactive updates using setAuth
//   const requestInterceptorRef = useRef(null);
//   const responseInterceptorRef = useRef(null);

//   useEffect(() => {
//     const auth = authStore.get();

//     // ✅ Cleanup existing interceptors (if they exist)
//     if (requestInterceptorRef.current) {
//       apiClientWithAuth.interceptors.request.eject(
//         requestInterceptorRef.current
//       );
//     }
//     if (responseInterceptorRef.current) {
//       apiClientWithAuth.interceptors.response.eject(
//         responseInterceptorRef.current
//       );
//     }

//     // ✅ Request Interceptor: Attach Access Token
//     requestInterceptorRef.current = apiClientWithAuth.interceptors.request.use(
//       (config) => {
//         const token = authStore.get()?.token;
//         if (token) {
//           console.log(LOG_TITLE, `🔥 Bearer ${token}`);
//           config.headers.Authorization = `Bearer ${token}`;
//         }
//         return config;
//       },
//       (error) => Promise.reject(error)
//     );

//     // ✅ Response Interceptor: Handle Token Expiry
//     responseInterceptorRef.current =
//       apiClientWithAuth.interceptors.response.use(
//         (response) => response,
//         async (error) => {
//           if (error.response?.status === 401) {
//             try {
//               console.log(LOG_TITLE, "🔄 Refreshing token...");
//               const refreshResponse = await apiClientWithAuth.get(
//                 "/auth/refreshtoken"
//               );
//               const newAccessToken = refreshResponse.data.accessToken;

//               console.log(
//                 LOG_TITLE,
//                 `✅ New token acquired: ${newAccessToken}`
//               );

//               // ✅ Update token in store using setAuth (triggers reactive update)
//               setAuth({ ...authStore.get(), token: newAccessToken });

//               // ✅ Retry original request with new token
//               error.config.headers.Authorization = `Bearer ${newAccessToken}`;
//               return apiClientWithAuth(error.config);
//             } catch (refreshError) {
//               console.error(
//                 LOG_TITLE,
//                 "❌ Failed to refresh token",
//                 refreshError
//               );
//               setAuth({}); // ✅ Clear auth state on failure
//               return Promise.reject(refreshError);
//             }
//           }
//           return Promise.reject(error);
//         }
//       );

//     // ✅ Cleanup on unmount (remove interceptors)
//     return () => {
//       if (requestInterceptorRef.current) {
//         apiClientWithAuth.interceptors.request.eject(
//           requestInterceptorRef.current
//         );
//       }
//       if (responseInterceptorRef.current) {
//         apiClientWithAuth.interceptors.response.eject(
//           responseInterceptorRef.current
//         );
//       }
//     };
//   }, [setAuth]); // ✅ Depend only on setAuth to prevent reruns

//   return apiClientWithAuth;
// };

// export default useAxiosWithAuth;
