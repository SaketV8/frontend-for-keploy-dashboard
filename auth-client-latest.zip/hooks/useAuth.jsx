import {
  authStore,
  persistStore,
  sessionSignalStore,
} from "@/auth/stores/authStore";
import { useStore } from "@nanostores/react";

// ✅ Direct hook to access and modify store data globally
const useAuth = () => {
  const LOG_TITLE = "🐦‍🔥 useAuth Hooks\n";

  const auth = useStore(authStore);
  const persist = useStore(persistStore);
  const sessionSignal = useStore(sessionSignalStore); // ✅ Listen for updates

  const setAuth = (newAuth) => {
    const currentAuth = authStore.get();

    // ✅ Only update if the state is different
    if (JSON.stringify(currentAuth) !== JSON.stringify(newAuth)) {
      console.log(LOG_TITLE, "👉 Before (setAuth):", {
        newAuth,
      });
      // console.log("👉 setAuth called with:", newAuth);
      authStore.set(newAuth); // ✅ Direct store update

      sessionSignalStore.set(!sessionSignalStore.get()); // ✅ Trigger update
      // console.log("☑️ Updated authStore: (useStore) ", auth);
      // console.log(LOG_TITLE, "👉👉 After (setAuth): (useStore)\n", auth);

      // console.log("✅ Updated authStore:", authStore.get());
      console.log(
        LOG_TITLE,
        "👉👉 After (setAuth): (get directly)\n",
        authStore.get()
      );
      // console.log(
      //   LOG_TITLE,
      //   "✅ Updated authStore: (get directly)",
      //   authStore.get()
      // );
    }
  };

  const setPersist = (newPersist) => {
    persistStore.set(newPersist);
  };

  const getAuth = authStore.get();

  const getPersist = persistStore.get();

  return {
    auth,
    setAuth,
    getAuth,
    persist,
    setPersist,
    getPersist,
    sessionSignal,
  };
};

export default useAuth;
